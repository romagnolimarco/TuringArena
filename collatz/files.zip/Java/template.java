class Solution extends Skeleton {

    int collatz(int n) {
        // TODO
        return 42;
    }
}
