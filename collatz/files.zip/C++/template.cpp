int collatz(int n) {
    // TODO
    return 42;
}
