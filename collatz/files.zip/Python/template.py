
def collatz(n):
    # TODO
    return 42

