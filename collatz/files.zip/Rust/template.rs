
pub fn collatz(n: i64) -> i64 {
    // TODO
    return 42;
}
