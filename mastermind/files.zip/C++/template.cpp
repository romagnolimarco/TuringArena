int play(int blackScore(int c1, int c2, int c3, int c4), int whiteScore(int c1, int c2, int c3, int c4)) {
    // TODO
    return 42;
}
