
def play(blackScore, whiteScore):
    # TODO
    return 42

