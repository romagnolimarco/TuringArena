
pub fn play(blackScore: fn(i64, i64, i64, i64)-> i64, whiteScore: fn(i64, i64, i64, i64)-> i64) -> i64 {
    // TODO
    return 42;
}
