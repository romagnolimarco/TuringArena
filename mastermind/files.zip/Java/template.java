class Solution extends Skeleton {

    int play(PlayCallbacks callbacks) {
        // TODO
        return 42;
    }
}
