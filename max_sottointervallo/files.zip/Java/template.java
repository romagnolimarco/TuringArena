class Solution extends Skeleton {

    int max_sottointervallo(int N, int seq[]) {
        // TODO
        return 42;
    }
}
