#MAX SOTTOINTERVALLO CRESCENTE (Trovare il massimo sottointervallo crescente)
Ricevete in input una sequenza di N numeri interi. In output dovete proporre un sottointervallo stret-
tamente crescente di interi estratta dalla sequenza in input che sia massimo in termini di numero di
elementi.

`Dati di input:`
La prima riga del file input.txt contiene un numero intero e positivo N, la lunghezza della sequenza
in input. La seconda riga contiene, in ordine, gli N numeri della sequenza.

`Dati di output:`
La prima riga del file output.txt deve contenere l’intero che rappresenta di quanti numeri risulta
composto il massimo sottointervallo crescente.

NB: 2 ≤ N ≤ 1000000 ciascun intero della sequenza è compreso tra -1000000 e 1000000.
