
pub fn max_sottointervallo(N: i64, seq: Vec<i64>) -> i64 {
    // TODO
    return 42;
}
