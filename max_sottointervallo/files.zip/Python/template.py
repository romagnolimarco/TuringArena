
def max_sottointervallo(N, seq):
    # TODO
    return 42

