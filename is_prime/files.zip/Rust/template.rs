
pub fn is_prime(n: i64) -> i64 {
    // TODO
    return 42;
}
