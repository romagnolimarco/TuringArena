
def is_prime(n):
    # TODO
    return 42

