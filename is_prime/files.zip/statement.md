# La Congettura di Collatz (Collatz)
Consideriamo il seguente algoritmo, che prende in ingresso un intero positivo n: Se n è primo l’algoritmo restituisce 1 altrimenti restituisce 0. 

# Obiettivo:
Scrivere una funzione del tipo:

int is_prime(int n){
	// your code
	return ...;
}

che avendo in input un numero n qualsiasi restituisca 1 se il numero è primo e 0 se non lo è.

