int is_prime(int n) {
    // TODO
    return 42;
}
