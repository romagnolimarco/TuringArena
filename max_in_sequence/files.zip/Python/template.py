
def max_index(n, a):
    # TODO
    return 42

