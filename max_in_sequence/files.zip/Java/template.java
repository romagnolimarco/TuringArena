class Solution extends Skeleton {

    int max_index(int n, int a[]) {
        // TODO
        return 42;
    }
}
