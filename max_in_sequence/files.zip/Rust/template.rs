
pub fn max_index(n: i64, a: Vec<i64>) -> i64 {
    // TODO
    return 42;
}
